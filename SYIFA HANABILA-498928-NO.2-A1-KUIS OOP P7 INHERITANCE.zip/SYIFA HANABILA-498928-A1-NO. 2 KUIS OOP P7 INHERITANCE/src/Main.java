public class Main {
    public static void main(String[] args) {
        //objek Student
        Student student = new Student("Budi", "CT.5 Sleman, DIY", "IPA", 3, 3000.0);
        System.out.println("Student:");
        System.out.println(student.getName());
        System.out.println(student.getAddress());
        System.out.println(student.getProgram());
        System.out.println(student.getYear());
        System.out.println(student.getFee());
        System.out.println(student.toString());
        System.out.println();

        //objek Staff
        Staff staff = new Staff("Yanto", "B03 Condongcatur, DIY", "SMKN 1 Yogyakarta", 5000.0);
        System.out.println("Staff");
        System.out.println(staff.getName());
        System.out.println(staff.getAddress());
        System.out.println(staff.getSchool());
        System.out.println(staff.getPay());
        System.out.println(staff.toString());
    }
}